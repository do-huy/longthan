<div class="container">
	<img id="footerimg" src="{{asset('images/footerimg.png')}}" alt="">
</div>
<div class="container">
	<div style="margin-bottom: 15px" class="col-md-5 col-sm-5">
		<img id="vdtg" src="{{asset('images/vdtg.jpg')}}" alt="">
	</div>
	<div class="col-md-7 col-sm-7">
		<p id="vdtg2"><b>GIỚI THIỆU VỀ VDTEXPRESS</b>
</p>
		<p id="vdtg1">VDTgroup khởi đầu với VDTexpress - là dịch vụ giao nhận
hàng hóa, ứng tiền, thu hộ, … giữa Long An và TpHCM
</p>
		<p id="vdtg1">VDTexpress được thành lập vào ngày 2/5/2018, tự hào là
đơn vị vận chuyển hàng đầu KV Đức Hòa, Đức Huệ/LA-SG</p>
		<p id="vdtg1">04/2019 VDTexpress hợp tác với SuperShip Việt Nam thành
lập SuperShip Long An – hoạt động lĩnh vực chuyển phát
nhanh Toàn Quốc</p>
<p id="vdtg1">Mục tiêu 2019 - 2020: VDTexpress cùng SPS
LA sẽ có mặt tại các Huyện còn lại của Tỉnh
Long An. Riêng VDTexpres Hướng đến mở
rộng phục vụ các tỉnh lân cận với TpHCM và
phát triển mô hình ra các trung tâm kinh tế khác
như Cần Thơ, Đà Nẵng, Hà Nội
</p>
<p id="vdtg1">Định hướng 2022: tận dụng Hệ Sinh Thái của
VDTgroup sẽ phát triển thêm các thương
hiệu VDTcoffee, VDTfood, VDTshop, …
</p>
	</div>
</div>

<div class="container">
	<img id="footerimg" src="{{asset('images/footerimg.png')}}" alt="">
</div>

<div class="container">
	<div class="col-md-4 col-sm-4">
		<p id="giua"><img id="tamnhin" src="{{asset('images/tamnhin.png')}}" alt=""></p>
		<p id="giua"> Tầm Nhìn</p>
		<p id="giua">Trở thành dịch vụ giao nhận chuyên nghiệp và
nhanh chóng hàng đầu các tuyến liên tỉnh với
cự ly dưới 100km từ TpHCM với các tỉnh lân
cận. Từ đó phát triển mô hình ra các trung tâm
kinh tế trọng điểm Toàn Quốc</p>
	</div>
	<div class="col-md-4 col-sm-4">
		<p id="giua"><img id="tamnhin" src="{{asset('images/sumenh.png')}}" alt=""></p>
		<p id="giua"> Tầm Nhìn</p>
		<p id="giua">Đơn giản hóa mọi quy trình xử lý và tối đa
hóa tốc độ giao hàng, đa dạng chủng loại
hàng hóa để đem lại lợi thế cạnh tranh trong
giao nhận cho các đối tác</p>
	</div>
	<div class="col-md-4 col-sm-4">
		<p id="giua"><img id="tamnhin" src="{{asset('images/kinhdoanh.png')}}" alt=""></p>
		<p id="giua">Triết Lý Kinh Doanh
</p>
		<p id="giua">Không gì là không thể , nếu sợ thì đừng làm , nếu làm thì đừng sợ</p>
	</div>
</div>