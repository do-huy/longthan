<div class="container">
	<img id="footerimg" src="{{asset('images/footerimg.png')}}" alt="">
</div>
<div class="container">
  <div>
  		<div class="col-md-6 col-sm-6">
  			<img id="vdtgroup" src="{{asset('images/vdtgroup.png')}}" alt="">
  		<p id="address"><i class="fas fa-map-marked-alt "></i> VP Tân Phú: 05 Đàm Thận Huy, Phường Phú Thọ Hòa, Q.Tân Phú, HCM</p>
  		<p id="address"><i class="fas fa-map-marked-alt "></i> VP ĐHòa: 322/2D , KV 4 , TT Đức Hòa , T.Long An</p>
  		<p id="address"><i class="fas fa-map-marked-alt "></i> VP ĐHuệ: 86 Tỉnh lộ 838 , KP 1 , T.T Đông Thành , H.Đức Huệ , T.Long An </p>
  		<p id="address"><i class="fas fa-map-marked-alt "></i> VP Quận 10: 147B Trần Bình Trọng, Phường 1 , Q.10, HCM</p>
  		<p id="address"><i class="fas fa-phone-volume"></i> Hotline: 0906676577</p>

  		</div>	
  		<div id="dichvu" class="col-md-6 col-sm-6">
  			<p id="dichvu" style="padding-top: 10px;color: #CC0000"><b>Dịch Vụ</b></p>
  			<p id="dichvu"><b><u>VDTexpress</u></b> là một ứng dụng giúp chủ cửa hàng và các doanh nghiệp có thể giải quyết vấn đề hàng hóa một cách nhanh chóng , tiện lợi. VDTexpress là một trong những ứng dụng hàng đầu trong lĩnh vực giao hàng nội thành tại TP Hồ Chí Minh và Long An.</p>
  			<p id="lk"><b><u>Liên Kết</u></b></p>
  			<p id="fb">
  				<a id="fb1" href="https://www.facebook.com/giaohangLonganSaiGon/?__tn__=%2Cd%2CP-R&eid=ARAI46EVhvlZeWQ0xwQQWnEHXJbQTOSKfo62H0imyobFSCbrQlvX6zQjWYcd5v6aO6fgUbkO0wmRQJSv" target="_blank">
  				<i class="fab fa-facebook-square">
  			</i> 
  				</a>
  				<a id="fb1" href="https://www.facebook.com/VDTexpress">
  				<i class="fab fa-facebook-square" target="_blank">	
  				</i>
  			</a>
  			</p>
  		</div>
  </div>
</div>
<div id="footer" class="row">
  <div>
	<div class="col-md-4 col-sm-4">
		<p style="margin-top: 8px;">© 2018 VDTexpress.com. All rights reserved</p>
	</div>

	<div  class="col-md-8 col-sm-8">
		<p style="float: right;margin-top: 8px;">Developed by IT VDTexpress</p>
	</div>
 </div>
</div>