    <div id="dathangf1" class="container">
      <p id="dathangf"><b>ĐẶT HÀNG VDTEXPRESS</b></p>
      <form action="">
        <div class="form-group">
          <label for="email">Người gửi:</label>
          <input type="name" class="form-control" id="email" placeholder="Tên người gửi" name="email">
        </div>
        <div class="form-group">
          <label for="pwd">Số điện thoại:</label>
          <input type="phone" class="form-control" id="pwd" placeholder="Số điện thoại người gửi" name="pwd">
        </div>
        <div class="form-group">
          <label for="pwd">Địa chỉ:</label>
          <input type="address" class="form-control" id="pwd" placeholder="Địa chỉ người gửi" name="pwd">
        </div>

        <div class="container">
        <img id="footerimg" src="{{asset('images/footerimg.png')}}" alt="">
        </div>

         <div class="form-group">
          <label for="email">Người gửi:</label>
          <input type="name" class="form-control" id="email" placeholder="Tên người gửi" name="email">
        </div>
        <div class="form-group">
          <label for="pwd">Số điện thoại:</label>
          <input type="phone" class="form-control" id="pwd" placeholder="Số điện thoại người gửi" name="pwd">
        </div>
        <div class="form-group">
          <label for="pwd">Địa chỉ:</label>
          <input type="address" class="form-control" id="pwd" placeholder="Địa chỉ người gửi" name="pwd">
        </div>
      
        <button type="submit" class="btn btn-default">Tạo đơn hàng</button>
      </form>
    </div>