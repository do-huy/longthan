<div style="text-align: center; margin-bottom: 40px; padding: 0 0 0px 0; border-bottom: 1px solid #e1293d;">
	<div class="container">
		<div class="row">
			<div class="col-sm-12 col-md-12">
			    <div style="margin: 10px auto;">
				<a href="<?php echo e(URL::Route('form')); ?>"><button type="submit" href="<?php echo e(URL::Route('form')); ?>" style="background: #fff; color: #a73a3a; padding: 7px 25px; border: 2px solid #a73a3a;"><span>TẠO ĐƠN HÀNG</span></button></a>
				</div>
			</div>
		</div>
	</div>
</div><?php /**PATH C:\xampp\htdocs\express\resources\views/index/content.blade.php ENDPATH**/ ?>