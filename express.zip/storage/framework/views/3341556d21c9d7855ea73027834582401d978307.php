<div class="container">
	<div class="detail"> 
	<p>Công ty <u><b>Chuyển Phát Nhanh Vận Đức Thành </b></u> chuyên kinh doanh dịch vụ chuyển phát nhanh trong nước các loại hàng hóa, bưu phẩm,…uy tín, giá rẻ nhất.</p>

	Hiện chúng tôi đã xây dựng được mạng lưới rộng Thành Phố Hồ Chí Minh - Long An, sẵn sàng đáp ứng tốt nhất mọi yêu cầu chuyển phát nhanh của Quý khách hàng thông qua các loại hình dịch vụ như:</div>

	<div class="detail1">
	<p>- Chuyển phát nhanh hỏa tốc.</p>
	<p>- Chuyển phát nhanh đảm bảo.</p>
	<p>- Chuyển phát nhanh hẹn giờ.</p>
	<p>- Chuyển phát trong ngày (HCM-LA) đi nhận hàng để chuyển phát trước 10h , Khách chủ động đến VDTexpress gửi hàng trước 12h</p>
	<p>- Chuyển phát hàng thu tiền ( COD) , ứng tiền trước cho khách hàng</p>
	</div>
</div><?php /**PATH C:\xampp\htdocs\express\resources\views/layouts/detail.blade.php ENDPATH**/ ?>